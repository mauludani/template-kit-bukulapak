import 'package:bukulapak/theme/theme.dart';
import 'package:bukulapak/widget/widgets.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';

part 'welcome_pages.dart';
part 'home_pages.dart';